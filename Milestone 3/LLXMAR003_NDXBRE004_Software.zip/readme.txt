update 20 Oct 22:11
pushed 4 files, PathNavV3, PathNavShortestRoute, robotParameters and createShortPath
Run robotParameters
Run PathNavV3 sim to "explore" maze using LSRB
Run createShortPath, creates shortest path directions
Run PathNavShortestRoute, which uses the directions mentioned above

****NB****
if changing robot start pos, edit the x and y variables in robotParameters to ensure a consistent start point across sims.